package com.entity;

public class BookOrder {
   private int id;
   private String orderId;
   private String username;
   private String email;
   private String phone;
   private String fulladd; 
   private String paymentType;
   private String bookname;
   private String author;
   private String price;
public BookOrder() {
	super();
	// TODO Auto-generated constructor stub
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getOrderId() {
	return orderId;
}
public void setOrderId(String orderId) {
	this.orderId = orderId;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getFulladd() {
	return fulladd;
}
public void setFulladd(String fulladd) {
	this.fulladd = fulladd;
}
public String getPaymentType() {
	return paymentType;
}
public void setPaymentType(String paymentType) {
	this.paymentType = paymentType;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
@Override
public String toString() {
	return "BookOrder [id=" + id + ", orderId=" + orderId + ", username=" + username + ", email=" + email + ", phone="
			+ phone + ", fulladd=" + fulladd + ", paymentType=" + paymentType + ", bookname=" + bookname + ", author="
			+ author + ", price=" + price + "]";
}

   
   
   
}